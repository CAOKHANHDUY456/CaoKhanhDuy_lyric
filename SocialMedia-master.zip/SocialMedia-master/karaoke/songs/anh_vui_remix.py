title = "Anh Vui (Remix)"
lyrics = {
    "sentence1": [
        { "time": 640, "text": "Cầm" },
        { "time": 1120, "text": "nhẫn" },
        { "time": 1320, "text": "cưới" },
        { "time": 1500, "text": "trên" },
        { "time": 1760, "text": "tay" }
    ],
    "sentence2": [
        { "time": 2140, "text": "Em" },
        { "time": 2680, "text": "vội" },
        { "time": 2840, "text": "lau" },
        { "time": 2840, "text": "đi" },
        { "time": 3280, "text": "nước" },
        { "time": 3280, "text": "mắt" },
        { "time": 3280, "text": "ngay" }
    ],
    "sentence3": [
        { "time": 4560, "text": "Đàn" },
        { "time": 4560, "text": "ông" },
        { "time": 4720, "text": "tốt" },
        { "time": 4940, "text": "như" },
        { "time": 5200, "text": "vậy" },
        { "time": 5680, "text": "nếu" }
    ],
    "sentence4": [
        { "time": 5820, "text": "Là" },
        { "time": 5980, "text": "anh" },
        { "time": 6220, "text": "cũng" },
        { "time": 6440, "text": "sẽ" },
        { "time": 6680, "text": "yêu" },
        { "time": 6880, "text": "thôi" }
    ],
    "sentence5": [
        { "time": 7440, "text": "Bờ" },
        { "time": 7980, "text": "môi" },
        { "time": 8160, "text": "đã" },
        { "time": 8320, "text": "chạm" },
        { "time": 8600, "text": "rồi" }
    ],
    "sentence6": [
        { "time": 9420, "text": "Anh" },
        { "time": 9660, "text": "cũng" },
        { "time": 9880, "text": "thấy" },
        { "time": 10140, "text": "bồi" },
        { "time": 10140, "text": "hồi" }
    ],
    "sentence7": [
        { "time": 10700, "text": "Thế" },
        { "time": 11160, "text": "nhưng" },
        { "time": 12200, "text": "thế" },
        { "time": 12760, "text": "nhưng" }
    ],
    "sentence8": [
        { "time": 13260, "text": "Anh" },
        { "time": 13720, "text": "vui" },
        { "time": 13960, "text": "đến" },
        { "time": 14160, "text": "nỗi" },
        { "time": 14380, "text": "nghẹn" },
        { "time": 14380, "text": "ngào" }
    ],
    "sentence9": [
        { "time": 15360, "text": "Nhìn" },
        { "time": 15400, "text": "người" },
        { "time": 15660, "text": "ta" },
        { "time": 15880, "text": "cầm" },
        { "time": 16079, "text": "nhẫn" },
        { "time": 16300, "text": "cưới" },
        { "time": 16580, "text": "trao" }
    ],
    "sentence10": [
        { "time": 16840, "text": "Anh" },
        { "time": 17160, "text": "cũng" },
        { "time": 17400, "text": "có" },
        { "time": 17580, "text": "chút" },
        { "time": 17820, "text": "tự" },
        { "time": 17820, "text": "hào" }
    ],
    "sentence11": [
        { "time": 18740, "text": "vì" },
        { "time": 18840, "text": "người" },
        { "time": 19060, "text": "mình" },
        { "time": 19300, "text": "thương" },
        { "time": 19500, "text": "hạnh" },
        { "time": 19800, "text": "phúc" },
        { "time": 19800, "text": "nhường" },
        { "time": 19800, "text": "nào" }
    ],
    "sentence12": [
        { "time": 20460, "text": "Áo" },
        { "time": 20640, "text": "cưới" },
        { "time": 20820, "text": "em" },
        { "time": 21220, "text": "màu" },
        { "time": 21220, "text": "trắng" },
        { "time": 21220, "text": "tinh" }
    ],
    "sentence13": [
        { "time": 22260, "text": "Cô" },
        { "time": 22360, "text": "gái" },
        { "time": 22540, "text": "anh" },
        { "time": 22760, "text": "thật" },
        { "time": 22980, "text": "rất" },
        { "time": 23280, "text": "xinh" }
    ],
    "sentence14": [
        { "time": 23980, "text": "Giật" },
        { "time": 24460, "text": "mình" },
        { "time": 24620, "text": "cứ" },
        { "time": 24880, "text": "ngỡ" }
    ],
    "sentence15": [
        { "time": 25120, "text": "Anh" },
        { "time": 25500, "text": "đứng" },
        { "time": 25700, "text": "cạnh" },
        { "time": 25920, "text": "em" },
        { "time": 26160, "text": "trong" },
        { "time": 26380, "text": "lễ" },
        { "time": 26380, "text": "cưới" }
    ],
    "sentence16": [
        { "time": 26980, "text": "Anh" },
        { "time": 27420, "text": "vui" },
        { "time": 27640, "text": "sao" },
        { "time": 27780, "text": "nước" },
        { "time": 27780, "text": "mắt" },
        { "time": 27780, "text": "cứ" },
        { "time": 27780, "text": "tuôn" },
        { "time": 27780, "text": "trào" }
    ],
    "sentence17": [
        { "time": 29020, "text": "Chẳng" },
        { "time": 29240, "text": "phải" },
        { "time": 29380, "text": "như" },
        { "time": 29600, "text": "thế" },
        { "time": 29780, "text": "quá" },
        { "time": 30020, "text": "tốt" },
        { "time": 30240, "text": "hay" },
        { "time": 30440, "text": "sao" }
    ],
    "sentence18": [
        { "time": 30920, "text": "Anh" },
        { "time": 31080, "text": "ta" },
        { "time": 31300, "text": "đáng" },
        { "time": 31520, "text": "giá" },
        { "time": 31700, "text": "nhường" },
        { "time": 31700, "text": "nào" }
    ],
    "sentence19": [
        { "time": 32520, "text": "Ngược" },
        { "time": 32600, "text": "lại" },
        { "time": 32800, "text": "nhìn" },
        { "time": 33040, "text": "anh" },
        { "time": 33240, "text": "trông" },
        { "time": 33420, "text": "chẳng" },
        { "time": 33660, "text": "ra" },
        { "time": 33820, "text": "sao" }
    ],
    "sentence20": [
        { "time": 34120, "text": "Cũng" },
        { "time": 34520, "text": "đúng" },
        { "time": 34960, "text": "thôi" }
    ],
    "sentence21": [
        { "time": 36320, "text": "Anh" },
        { "time": 36420, "text": "làm" },
        { "time": 36660, "text": "gì" },
        { "time": 37780, "text": "xứng" },
        { "time": 37940, "text": "đáng" },
        { "time": 38140, "text": "với" },
        { "time": 38620, "text": "em" }
    ]
}
